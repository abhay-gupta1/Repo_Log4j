package LoggingSample.log4jProject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Hello world!
 *
 */
public class App 
{
	private static Logger logger = LogManager.getLogger(App.class);
    public static void main( String[] args )
    {
    	
    	logger.error("logger is configured correctly");
        System.out.println( "Hello World!" );
    }
}
